This is a RF switch using the HSWA2-30DR+
The sma connectors used are: 
931-1175-ND  https://www.digikey.com/products/en?keywords=931-1175-ND
CONSMA013.062-ND  https://www.digikey.com/products/en?keywords=CONSMA013.062-ND